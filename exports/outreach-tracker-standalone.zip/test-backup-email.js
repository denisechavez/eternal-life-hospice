/**
 * test-backup-email.js
 *
 * Integration test for the on-demand full-backup flow.
 *
 * What it verifies:
 *   1. runWeeklyBackup({ forceFullBackup: true }) completes without error.
 *   2. backup_log receives a new row with status='ok' and note starting with
 *      "On-demand full backup".
 *   3. The Brevo request carries a well-formed CSV attachment:
 *        a. Header row contains all 19 expected column names in the right order.
 *        b. Data-row count equals the total visits in the DB at run time.
 *        c. The attachment content round-trips cleanly through base64.
 *   4. The Brevo request is addressed to BACKUP_EMAIL.
 *
 * The test never sends real email — it substitutes a fake https module that
 * returns HTTP 201 and captures the outbound request body.
 *
 * Usage:
 *   DATABASE_URL=postgres://... BACKUP_EMAIL=test@example.com BREVO_API=fake \
 *     node test-backup-email.js
 *
 * Exit codes: 0 = all assertions passed, 1 = a failure occurred.
 */

"use strict";

const { Pool } = require("pg");
const EventEmitter = require("events");

// ---- env checks ----
if (!process.env.DATABASE_URL) {
  console.error("ERROR: DATABASE_URL is not set.");
  process.exit(1);
}
if (!process.env.BACKUP_EMAIL) {
  console.error(
    "ERROR: BACKUP_EMAIL is not set — backup email test cannot run.\n" +
    "       Set BACKUP_EMAIL (and BREVO_API) to run the full integration test."
  );
  process.exit(1);
}
if (!process.env.BREVO_API) {
  // Allow any non-empty value — the fake https module never validates it.
  console.error(
    "ERROR: BREVO_API is not set — backup email test cannot run.\n" +
    "       Set BREVO_API (any non-empty value works; real sends are intercepted) to run."
  );
  process.exit(1);
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Override the module-level pool used by backup.js's db.js require.
// backup.js calls require("./db") which returns a singleton pool from db.js.
// We don't re-pool here; we just reuse the same DATABASE_URL via the env.

const { runWeeklyBackup } = require("./backup");

// ---- assertion helper ----
function assert(condition, message) {
  if (!condition) {
    console.error(`  FAIL: ${message}`);
    process.exitCode = 1;
  } else {
    console.log(`  PASS: ${message}`);
  }
}

// ---- fake https module ----
// Returns a mock that:
//   • accepts https.request(options, callback)
//   • calls callback with a fake IncomingMessage (statusCode 201)
//   • captures everything written via req.write() into capturedBody
//   • exposes capturedOptions (the request options object)
function makeFakeHttps() {
  let capturedBody = "";
  let capturedOptions = null;

  const fakeHttps = {
    request(options, callback) {
      capturedOptions = options;

      // Build a fake response that fires the 'end' event synchronously
      // after the test calls req.end().
      const fakeRes = new EventEmitter();
      fakeRes.statusCode = 201;

      const fakeReq = new EventEmitter();
      fakeReq.setTimeout = () => {};
      fakeReq.destroy = (err) => fakeReq.emit("error", err);
      fakeReq.write = (chunk) => { capturedBody += chunk; };
      fakeReq.end = () => {
        // Simulate async response
        setImmediate(() => {
          callback(fakeRes);
          setImmediate(() => fakeRes.emit("end"));
        });
      };
      return fakeReq;
    },

    get captured() {
      return {
        options: capturedOptions,
        body: capturedBody,
        parsed: capturedBody ? JSON.parse(capturedBody) : null,
      };
    },
  };

  return fakeHttps;
}

// ---- test ----
async function run() {
  console.log("=== on-demand backup email integration test ===\n");

  const SENTINEL = "test-backup-email-script";

  // Verify both tables exist (must be created by schema.sql before tests run).
  // We deliberately do NOT issue CREATE TABLE here: a missing table is a setup
  // error — fail loudly so the operator knows to run the migration first.
  for (const tableName of ["visits", "backup_log"]) {
    const tableCheck = await pool.query(`
      SELECT 1 FROM information_schema.tables
       WHERE table_schema = 'public'
         AND table_name   = $1
    `, [tableName]);
    if (tableCheck.rows.length === 0) {
      console.error(
        `ERROR: ${tableName} table does not exist.\n` +
        "       Run the schema migration first:  psql $DATABASE_URL < schema.sql"
      );
      process.exit(1);
    }
  }

  // --- Count existing visits so we know what a full backup should include ---
  const beforeCount = await pool.query("SELECT COUNT(*)::int AS n FROM visits");
  const existingVisitCount = beforeCount.rows[0].n;

  // --- Insert 2 sentinel visits ---
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES
       ($1, true, 'sentinel-A'),
       ($1, true, 'sentinel-B')`,
    [SENTINEL]
  );
  const expectedRowCount = existingVisitCount + 2;

  // --- Remember the backup_log high-water mark so we can isolate our new row ---
  const hwmRes = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm = hwmRes.rows[0].hwm;

  // --- Run the backup with a fake https module ---
  const fakeHttps = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: true, _httpsOverride: fakeHttps });

  // ---- 1. backup_log row ----
  const logRes = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm]
  );
  assert(logRes.rows.length === 1, "backup_log received exactly 1 new row");
  if (logRes.rows.length) {
    const { status, note } = logRes.rows[0];
    assert(status === "ok", `backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("On-demand full backup"),
      `backup_log note starts with "On-demand full backup" (got: "${note}")`
    );
  }

  // ---- 2. Brevo request was made ----
  const { options, parsed } = fakeHttps.captured;
  assert(options !== null, "Brevo https.request was called");
  assert(
    options && options.hostname === "api.brevo.com",
    `Brevo hostname is api.brevo.com (got '${options && options.hostname}')`
  );

  if (parsed) {
    // ---- 3. Recipient ----
    const toEmail =
      parsed.to && parsed.to[0] && parsed.to[0].email;
    assert(
      toEmail === process.env.BACKUP_EMAIL,
      `Email addressed to BACKUP_EMAIL (${process.env.BACKUP_EMAIL}) — got '${toEmail}'`
    );

    // ---- 4. Attachment present ----
    const attachments = parsed.attachment || [];
    assert(attachments.length === 1, `1 attachment present (got ${attachments.length})`);

    if (attachments.length) {
      const att = attachments[0];

      // ---- 5. Filename contains 'Full' ----
      assert(
        att.name && att.name.includes("Full"),
        `attachment filename contains 'Full' (got '${att.name}')`
      );

      // ---- 6. Decode CSV ----
      let csv = "";
      try {
        csv = Buffer.from(att.content, "base64").toString("utf8");
      } catch (_) {}
      assert(csv.length > 0, "attachment content decodes from base64 to non-empty string");

      const lines = csv.split(/\r?\n/).filter(Boolean);
      const headerLine = lines[0] || "";

      // ---- 7. Header columns (order matters) ----
      const EXPECTED_FIELDS = [
        "id", "company", "category", "address", "city", "county", "visit_date",
        "contact_name", "contact_title", "contact_email", "contact_phone",
        "materials", "notes", "owner", "follow_up_due", "followup_status",
        "attested", "created_at", "updated_at",
      ];
      const headerCols = headerLine.split(",");
      assert(
        headerCols.length === EXPECTED_FIELDS.length,
        `CSV header has ${EXPECTED_FIELDS.length} columns (got ${headerCols.length})`
      );
      EXPECTED_FIELDS.forEach((col, i) => {
        assert(
          headerCols[i] === col,
          `CSV column[${i}] = '${col}' (got '${headerCols[i]}')`
        );
      });

      // ---- 8. Data row count matches DB ----
      const dataRowCount = lines.length - 1; // subtract header
      assert(
        dataRowCount === expectedRowCount,
        `CSV data rows = total visits in DB (${expectedRowCount}), got ${dataRowCount}`
      );

      // ---- 9. Sentinel rows are in the CSV ----
      const csvBody = lines.slice(1).join("\n");
      assert(
        csvBody.includes(SENTINEL),
        "sentinel company name appears in CSV data rows"
      );
    }
  }

  // --- Cleanup: remove sentinel visits and the backup_log row we created ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm]);

  const cleanV = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1",
    [SENTINEL]
  );
  assert(cleanV.rows[0].n === 0, "sentinel visits cleaned up");

  const cleanL = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1",
    [hwm]
  );
  assert(cleanL.rows[0].n === 0, "test backup_log rows cleaned up");

  console.log("\n=== Done (full-backup test) ===");
}

// ---------------------------------------------------------------------------
// Incremental backup test
//
// Verifies that a normal (non-forced) runWeeklyBackup:
//   • includes only records whose updated_at is AFTER the last successful run
//   • excludes records that have not changed since then
//   • writes a backup_log row whose note starts with "Incremental backup"
//     and shows the correct record count
// ---------------------------------------------------------------------------
async function runIncrementalTest() {
  console.log("\n=== incremental backup integration test ===\n");

  const SENTINEL_PRE = "test-backup-incr-pre";   // unmodified record — must NOT appear
  const SENTINEL_NEW = "test-backup-incr-new";   // record changed after last backup — MUST appear

  // High-water mark so cleanup is surgical
  const hwmRes = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm = hwmRes.rows[0].hwm;

  // 1. Insert the "old" sentinel visit, then push its updated_at 2 hours into
  //    the past so it predates the simulated last successful backup.
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES ($1, false, 'incr-sentinel-pre')`,
    [SENTINEL_PRE]
  );
  await pool.query(
    `UPDATE visits SET updated_at = NOW() - INTERVAL '2 hours'
     WHERE company = $1`,
    [SENTINEL_PRE]
  );

  // 2. Seed a successful backup_log row dated 1 hour ago.  This becomes
  //    lastSuccessfulAt for the incremental query (updated_at > lastSuccessfulAt).
  await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW() - INTERVAL '1 hour', 'ok',
             'Seeded by incremental test — safe to delete')`,
  );

  // 3. Insert the "new" sentinel visit.  Its updated_at = NOW(), which is
  //    after the seeded backup, so the incremental query must pick it up.
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES ($1, false, 'incr-sentinel-new')`,
    [SENTINEL_NEW]
  );

  // 4. Run the incremental backup (forceFullBackup defaults to false).
  const fakeHttps2 = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttps2 });

  // ---- A. backup_log row ----
  const logRes = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm]
  );
  assert(logRes.rows.length >= 1, "incremental: backup_log received at least 1 new row");
  if (logRes.rows.length) {
    const { status, note } = logRes.rows[0];
    assert(status === "ok", `incremental: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `incremental: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
    // The note embeds the record count: "Incremental backup: N record(s) …"
    // Assert ≥ 1 rather than exactly 1: other records in a live DB may also
    // have been updated recently and will legitimately appear in the window.
    const match = note && note.match(/^Incremental backup:\s+(\d+)\s+record/);
    assert(
      match !== null,
      `incremental: backup_log note contains a record count (got: "${note}")`
    );
    if (match) {
      assert(
        parseInt(match[1], 10) >= 1,
        `incremental: backup_log note reports at least 1 changed record (got ${match[1]})`
      );
    }
  }

  // ---- B. Brevo request was made ----
  const { options: incrOpts, parsed: incrParsed } = fakeHttps2.captured;
  assert(incrOpts !== null, "incremental: Brevo https.request was called");

  if (incrParsed) {
    // ---- C. Filename contains 'Incremental' ----
    const attachments = incrParsed.attachment || [];
    assert(attachments.length === 1, `incremental: 1 attachment present (got ${attachments.length})`);

    if (attachments.length) {
      const att = attachments[0];
      assert(
        att.name && att.name.includes("Incremental"),
        `incremental: attachment filename contains 'Incremental' (got '${att.name}')`
      );

      // ---- D. Decode CSV and check row counts ----
      let csv = "";
      try { csv = Buffer.from(att.content, "base64").toString("utf8"); } catch (_) {}
      assert(csv.length > 0, "incremental: attachment decodes to non-empty string");

      const lines = csv.split(/\r?\n/).filter(Boolean);
      const dataRowCount = lines.length - 1; // subtract header
      // Assert ≥ 1 rather than exactly 1: other records updated within the
      // cutoff window in a live DB will also appear legitimately.
      assert(
        dataRowCount >= 1,
        `incremental: CSV contains at least 1 data row (got ${dataRowCount})`
      );

      // ---- E. Updated sentinel IS in the CSV ----
      const csvBody = lines.slice(1).join("\n");
      assert(
        csvBody.includes(SENTINEL_NEW),
        `incremental: updated sentinel ('${SENTINEL_NEW}') appears in CSV`
      );

      // ---- F. Unmodified sentinel is NOT in the CSV ----
      assert(
        !csvBody.includes(SENTINEL_PRE),
        `incremental: unmodified sentinel ('${SENTINEL_PRE}') does NOT appear in CSV`
      );
    }
  }

  // --- Cleanup ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_PRE]);
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_NEW]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm]);

  const cleanPre = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_PRE]
  );
  assert(cleanPre.rows[0].n === 0, "incremental: SENTINEL_PRE visits cleaned up");

  const cleanNew = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_NEW]
  );
  assert(cleanNew.rows[0].n === 0, "incremental: SENTINEL_NEW visits cleaned up");

  const cleanL = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm]
  );
  assert(cleanL.rows[0].n === 0, "incremental: test backup_log rows cleaned up");

  console.log("\n=== Done (incremental backup test) ===");
}

// ---------------------------------------------------------------------------
// Incremental backup — no-change test
//
// Verifies that when nothing has changed since the last successful backup
// the backup still:
//   • sends an email (Brevo request is made)
//   • attaches a well-formed CSV that contains ONLY the header row (0 data rows)
//   • writes a backup_log note reporting "Incremental backup: 0 record(s)…"
// ---------------------------------------------------------------------------
async function runIncrementalNoChangeTest() {
  console.log("\n=== incremental backup — no-change test ===\n");

  // High-water mark so cleanup is surgical
  const hwmRes = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm = hwmRes.rows[0].hwm;

  // Seed a successful backup_log row at NOW().
  // All visits already in the DB have updated_at <= NOW(), so the incremental
  // query (updated_at > lastSuccessfulAt) will return 0 rows.
  await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW(), 'ok',
             'Seeded by no-change incremental test — safe to delete')`
  );

  // Run the incremental backup — nothing has changed since NOW().
  const fakeHttps3 = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttps3 });

  // ---- A. backup_log row ----
  const logRes = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm]
  );
  assert(logRes.rows.length >= 1, "no-change: backup_log received at least 1 new row");
  if (logRes.rows.length) {
    const { status, note } = logRes.rows[0];
    assert(status === "ok", `no-change: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `no-change: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
    const match = note && note.match(/^Incremental backup:\s+(\d+)\s+record/);
    assert(
      match !== null,
      `no-change: backup_log note contains a record count (got: "${note}")`
    );
    if (match) {
      assert(
        parseInt(match[1], 10) === 0,
        `no-change: backup_log note reports 0 changed records (got ${match[1]})`
      );
    }
  }

  // ---- B. Brevo request was still made ----
  const { options: noChangeOpts, parsed: noChangeParsed } = fakeHttps3.captured;
  assert(noChangeOpts !== null, "no-change: Brevo https.request was called");

  if (noChangeParsed) {
    // ---- C. Attachment present ----
    const attachments = noChangeParsed.attachment || [];
    assert(
      attachments.length === 1,
      `no-change: 1 attachment present (got ${attachments.length})`
    );

    if (attachments.length) {
      const att = attachments[0];

      // ---- D. Filename contains 'Incremental' ----
      assert(
        att.name && att.name.includes("Incremental"),
        `no-change: attachment filename contains 'Incremental' (got '${att.name}')`
      );

      // ---- E. Decode CSV — header only, 0 data rows ----
      let csv = "";
      try { csv = Buffer.from(att.content, "base64").toString("utf8"); } catch (_) {}
      assert(
        csv.length > 0,
        "no-change: attachment decodes to non-empty string (header row is present)"
      );

      const lines = csv.split(/\r?\n/).filter(Boolean);
      assert(lines.length >= 1, "no-change: CSV has at least the header row");

      const dataRowCount = lines.length - 1; // subtract header
      assert(
        dataRowCount === 0,
        `no-change: CSV contains exactly 0 data rows (got ${dataRowCount})`
      );

      // ---- F. Header is still well-formed ----
      const EXPECTED_FIELDS = [
        "id", "company", "category", "address", "city", "county", "visit_date",
        "contact_name", "contact_title", "contact_email", "contact_phone",
        "materials", "notes", "owner", "follow_up_due", "followup_status",
        "attested", "created_at", "updated_at",
      ];
      const headerCols = (lines[0] || "").split(",");
      assert(
        headerCols.length === EXPECTED_FIELDS.length,
        `no-change: CSV header has ${EXPECTED_FIELDS.length} columns (got ${headerCols.length})`
      );
      EXPECTED_FIELDS.forEach((col, i) => {
        assert(
          headerCols[i] === col,
          `no-change: CSV column[${i}] = '${col}' (got '${headerCols[i]}')`
        );
      });
    }
  }

  // --- Cleanup ---
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm]);

  const cleanL = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm]
  );
  assert(cleanL.rows[0].n === 0, "no-change: test backup_log rows cleaned up");

  console.log("\n=== Done (incremental no-change test) ===");
}

// ---------------------------------------------------------------------------
// Boundary-timestamp test
//
// The incremental WHERE clause is:  updated_at > $1  (strict greater-than).
// A record whose updated_at equals the cutoff exactly is intentionally
// excluded — the assumption is that it was already captured by the backup
// that produced that ran_at timestamp.
//
// This test pins that contract so any future change to ">=" is caught.
// ---------------------------------------------------------------------------
async function runBoundaryTest() {
  console.log("\n=== incremental backup boundary-timestamp test ===\n");
  console.log(
    "  (Documents intentional behaviour: updated_at = ran_at is excluded by strict >)"
  );

  const SENTINEL_BOUNDARY = "test-backup-boundary";

  // High-water mark for surgical cleanup
  const hwmRes2 = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm2 = hwmRes2.rows[0].hwm;

  // 1. Seed a successful backup_log row 5 seconds in the future so it is
  //    guaranteed to be the latest 'ok' row regardless of any pre-existing
  //    rows in the database.  Capture its exact ran_at so we can align
  //    the sentinel visit's updated_at to the same microsecond.
  const logInsert = await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW() + INTERVAL '5 seconds', 'ok',
             'Seeded by boundary test — safe to delete')
     RETURNING ran_at`
  );
  const cutoff = logInsert.rows[0].ran_at; // exact timestamp as JS Date

  // Verify this row is indeed the effective cutoff that runWeeklyBackup will use.
  const effectiveCutoffRes = await pool.query(
    `SELECT ran_at FROM backup_log WHERE status = 'ok' ORDER BY ran_at DESC LIMIT 1`
  );
  assert(
    effectiveCutoffRes.rows.length === 1 &&
      effectiveCutoffRes.rows[0].ran_at.getTime() === cutoff.getTime(),
    `boundary: seeded log row IS the effective cutoff (ran_at=${cutoff.toISOString()})`
  );

  // 2. Insert a sentinel visit and set its updated_at to the EXACT cutoff.
  //    With strict ">", this record must not appear in the incremental backup.
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES ($1, false, 'boundary-sentinel')`,
    [SENTINEL_BOUNDARY]
  );
  await pool.query(
    `UPDATE visits SET updated_at = $1 WHERE company = $2`,
    [cutoff, SENTINEL_BOUNDARY]
  );

  // Confirm the update took effect at the exact cutoff microsecond.
  const sentinelTsRes = await pool.query(
    `SELECT updated_at FROM visits WHERE company = $1`, [SENTINEL_BOUNDARY]
  );
  assert(
    sentinelTsRes.rows.length === 1 &&
      sentinelTsRes.rows[0].updated_at.getTime() === cutoff.getTime(),
    `boundary: sentinel updated_at = cutoff exactly (${cutoff.toISOString()})`
  );

  // 3. Run the incremental backup (no force-full).
  const fakeHttps4 = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttps4 });

  // ---- A. backup_log row produced ----
  const logRes2 = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm2]
  );
  assert(logRes2.rows.length >= 1, "boundary: backup_log received at least 1 new row");
  if (logRes2.rows.length) {
    const { status, note } = logRes2.rows[0];
    assert(status === "ok", `boundary: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `boundary: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
  }

  // ---- B. Brevo request was made ----
  const { options: bndOpts, parsed: bndParsed } = fakeHttps4.captured;
  assert(bndOpts !== null, "boundary: Brevo https.request was called");

  if (bndParsed) {
    const attachments = bndParsed.attachment || [];
    assert(attachments.length === 1, `boundary: 1 attachment present (got ${attachments.length})`);

    if (attachments.length) {
      let csv = "";
      try { csv = Buffer.from(attachments[0].content, "base64").toString("utf8"); } catch (_) {}
      assert(csv.length > 0, "boundary: attachment decodes to non-empty string");

      const lines = csv.split(/\r?\n/).filter(Boolean);
      const csvBody = lines.slice(1).join("\n");

      // ---- C. Boundary record is NOT in the CSV (strict > intentional) ----
      assert(
        !csvBody.includes(SENTINEL_BOUNDARY),
        `boundary: record with updated_at = cutoff is excluded (strict > is intentional)`
      );
    }
  }

  // --- Cleanup ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_BOUNDARY]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm2]);

  const cleanV = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_BOUNDARY]
  );
  assert(cleanV.rows[0].n === 0, "boundary: sentinel visit cleaned up");

  const cleanL2 = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm2]
  );
  assert(cleanL2.rows[0].n === 0, "boundary: test backup_log rows cleaned up");

  console.log("\n=== Done (boundary-timestamp test) ===");
}

// ---------------------------------------------------------------------------
// Boundary +1 ms test
//
// Complements runBoundaryTest by pinning the LOWER BOUND: the smallest
// possible timestamp that MUST appear in an incremental backup.
//
// The incremental WHERE clause is:  updated_at > $1  (strict greater-than).
// A record with updated_at = ran_at + 1 ms is the first timestamp that
// satisfies the condition.  PostgreSQL stores timestamps at microsecond
// resolution, so JavaScript Date rounding could in theory cause the +1 ms
// record to be collapsed back to the cutoff and silently dropped.
// This test confirms that never happens.
// ---------------------------------------------------------------------------
async function runBoundaryPlusOneTest() {
  console.log("\n=== incremental backup boundary +1 ms test ===\n");
  console.log(
    "  (Pins lower bound: updated_at = ran_at + 1ms MUST appear in the backup)"
  );

  const SENTINEL_PLUS1 = "test-backup-boundary-plus1ms";

  // High-water mark for surgical cleanup
  const hwmRes3 = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm3 = hwmRes3.rows[0].hwm;

  // 1. Seed a successful backup_log row 5 seconds in the future so it is
  //    guaranteed to be the latest 'ok' row.  Capture its exact ran_at so
  //    we can derive the +1 ms updated_at directly in SQL.
  const logInsert3 = await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW() + INTERVAL '5 seconds', 'ok',
             'Seeded by boundary+1ms test — safe to delete')
     RETURNING ran_at`
  );
  const cutoff3 = logInsert3.rows[0].ran_at; // exact timestamp as JS Date

  // Confirm this row is the effective cutoff runWeeklyBackup will use.
  const effectiveCutoffRes3 = await pool.query(
    `SELECT ran_at FROM backup_log WHERE status = 'ok' ORDER BY ran_at DESC LIMIT 1`
  );
  assert(
    effectiveCutoffRes3.rows.length === 1 &&
      effectiveCutoffRes3.rows[0].ran_at.getTime() === cutoff3.getTime(),
    `boundary+1ms: seeded log row IS the effective cutoff (ran_at=${cutoff3.toISOString()})`
  );

  // 2. Insert a sentinel visit and set its updated_at to ran_at + 1 ms via SQL
  //    so the microsecond-precise value is computed entirely inside PostgreSQL
  //    (avoids any JavaScript Date rounding artefacts).
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES ($1, false, 'boundary+1ms-sentinel')`,
    [SENTINEL_PLUS1]
  );
  await pool.query(
    `UPDATE visits
        SET updated_at = $1::timestamptz + INTERVAL '1 millisecond'
      WHERE company = $2`,
    [cutoff3, SENTINEL_PLUS1]
  );

  // Confirm the sentinel's updated_at is strictly after the cutoff.
  // We use > rather than === cutoff+1 because pg preserves sub-millisecond
  // (microsecond) precision as a float in Date.getTime(), so exact integer
  // arithmetic is unreliable.  The important property is that the value is
  // strictly greater than the cutoff — which is what the WHERE clause tests.
  const sentinelTsRes3 = await pool.query(
    `SELECT updated_at FROM visits WHERE company = $1`, [SENTINEL_PLUS1]
  );
  assert(
    sentinelTsRes3.rows.length === 1 &&
      sentinelTsRes3.rows[0].updated_at.getTime() > cutoff3.getTime(),
    `boundary+1ms: sentinel updated_at is strictly after the cutoff ` +
      `(cutoff=${cutoff3.toISOString()}, ` +
      `got ${sentinelTsRes3.rows.length ? sentinelTsRes3.rows[0].updated_at.toISOString() : "none"})`
  );

  // 3. Run the incremental backup.
  const fakeHttps5 = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttps5 });

  // ---- A. backup_log row produced ----
  const logRes3 = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm3]
  );
  assert(logRes3.rows.length >= 1, "boundary+1ms: backup_log received at least 1 new row");
  if (logRes3.rows.length) {
    const { status, note } = logRes3.rows[0];
    assert(status === "ok", `boundary+1ms: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `boundary+1ms: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
    // The note embeds the record count — must be >= 1.
    const match3 = note && note.match(/^Incremental backup:\s+(\d+)\s+record/);
    assert(
      match3 !== null,
      `boundary+1ms: backup_log note contains a record count (got: "${note}")`
    );
    if (match3) {
      assert(
        parseInt(match3[1], 10) >= 1,
        `boundary+1ms: backup_log note reports at least 1 changed record (got ${match3[1]})`
      );
    }
  }

  // ---- B. Brevo request was made ----
  const { options: plus1Opts, parsed: plus1Parsed } = fakeHttps5.captured;
  assert(plus1Opts !== null, "boundary+1ms: Brevo https.request was called");

  if (plus1Parsed) {
    const attachments3 = plus1Parsed.attachment || [];
    assert(
      attachments3.length === 1,
      `boundary+1ms: 1 attachment present (got ${attachments3.length})`
    );

    if (attachments3.length) {
      let csv3 = "";
      try { csv3 = Buffer.from(attachments3[0].content, "base64").toString("utf8"); } catch (_) {}
      assert(csv3.length > 0, "boundary+1ms: attachment decodes to non-empty string");

      const lines3 = csv3.split(/\r?\n/).filter(Boolean);
      const dataRowCount3 = lines3.length - 1; // subtract header
      assert(
        dataRowCount3 >= 1,
        `boundary+1ms: CSV contains at least 1 data row (got ${dataRowCount3})`
      );

      const csvBody3 = lines3.slice(1).join("\n");

      // ---- C. The +1 ms record IS in the CSV ----
      assert(
        csvBody3.includes(SENTINEL_PLUS1),
        `boundary+1ms: record with updated_at = cutoff + 1ms IS included in the incremental CSV`
      );
    }
  }

  // --- Cleanup ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_PLUS1]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm3]);

  const cleanV3 = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_PLUS1]
  );
  assert(cleanV3.rows[0].n === 0, "boundary+1ms: sentinel visit cleaned up");

  const cleanL3 = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm3]
  );
  assert(cleanL3.rows[0].n === 0, "boundary+1ms: test backup_log rows cleaned up");

  console.log("\n=== Done (boundary +1 ms test) ===");
}

// ---------------------------------------------------------------------------
// Clock-skew boundary test
//
// In the laboratory tests above, backup_log.ran_at and the sentinel visit's
// updated_at are always seeded inside the same transaction or via explicit SQL
// arithmetic — so they are perfectly synchronised.  In production the backup
// may take several milliseconds between writing the backup_log row and the
// moment a concurrent INSERT lands on the DB server, so NOW() at INSERT time
// is genuinely a few ms after ran_at.
//
// This test exercises that real-world path:
//   1. Seed backup_log.ran_at with NOW() and capture the exact value.
//   2. Wait ~5 ms in JavaScript (setTimeout) so real wall-clock time passes.
//   3. Insert the sentinel visit — its updated_at is DB-side NOW() at insert
//      time, which is genuinely *after* ran_at by the elapsed wall-clock gap.
//   4. Confirm the sentinel appears in the incremental CSV.
// ---------------------------------------------------------------------------
async function runClockSkewTest() {
  console.log("\n=== incremental backup clock-skew boundary test ===\n");
  console.log(
    "  (Seeds log row, waits ~5 ms real time, inserts sentinel at NOW() — " +
    "mirrors production clock drift)"
  );

  const SENTINEL_SKEW = "test-backup-clock-skew";

  // High-water mark for surgical cleanup
  const hwmRes4 = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm4 = hwmRes4.rows[0].hwm;

  // 1. Seed a successful backup_log row at NOW() and capture its exact ran_at.
  //    We use NOW() + 0 so the row is clearly the latest 'ok' entry but does
  //    not push into the future (unlike the boundary tests), so the incremental
  //    query will pick up any record inserted *after* this moment.
  const logInsert4 = await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW(), 'ok',
             'Seeded by clock-skew test — safe to delete')
     RETURNING ran_at`
  );
  const cutoff4 = logInsert4.rows[0].ran_at; // exact JS Date from PostgreSQL

  // Confirm this is indeed the effective cutoff.
  const effectiveCutoffRes4 = await pool.query(
    `SELECT ran_at FROM backup_log WHERE status = 'ok' ORDER BY ran_at DESC LIMIT 1`
  );
  assert(
    effectiveCutoffRes4.rows.length === 1 &&
      effectiveCutoffRes4.rows[0].ran_at.getTime() === cutoff4.getTime(),
    `clock-skew: seeded log row IS the effective cutoff (ran_at=${cutoff4.toISOString()})`
  );

  // 2. Wait ~5 ms so the DB-side NOW() at the next INSERT is genuinely after
  //    ran_at — simulating the small wall-clock gap that occurs in production
  //    between writing the backup_log row and a concurrent visit update.
  await new Promise((resolve) => setTimeout(resolve, 5));

  // 3. Insert the sentinel at real DB-side NOW() (no manual timestamp override).
  //    updated_at defaults to NOW(), which is the DB clock's current time.
  await pool.query(
    `INSERT INTO visits (company, attested, notes)
     VALUES ($1, false, 'clock-skew-sentinel')`,
    [SENTINEL_SKEW]
  );

  // Verify the sentinel's updated_at is strictly after the cutoff.
  const sentinelTsRes4 = await pool.query(
    `SELECT updated_at FROM visits WHERE company = $1`, [SENTINEL_SKEW]
  );
  assert(
    sentinelTsRes4.rows.length === 1 &&
      sentinelTsRes4.rows[0].updated_at.getTime() > cutoff4.getTime(),
    `clock-skew: sentinel updated_at is strictly after the seeded ran_at ` +
      `(ran_at=${cutoff4.toISOString()}, ` +
      `updated_at=${sentinelTsRes4.rows.length ? sentinelTsRes4.rows[0].updated_at.toISOString() : "none"})`
  );

  // 4. Run the incremental backup.
  const fakeHttps6 = makeFakeHttps();
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttps6 });

  // ---- A. backup_log row produced ----
  const logRes4 = await pool.query(
    `SELECT status, note FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm4]
  );
  assert(logRes4.rows.length >= 1, "clock-skew: backup_log received at least 1 new row");
  if (logRes4.rows.length) {
    const { status, note } = logRes4.rows[0];
    assert(status === "ok", `clock-skew: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `clock-skew: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
    const match4 = note && note.match(/^Incremental backup:\s+(\d+)\s+record/);
    assert(
      match4 !== null,
      `clock-skew: backup_log note contains a record count (got: "${note}")`
    );
    if (match4) {
      assert(
        parseInt(match4[1], 10) >= 1,
        `clock-skew: backup_log note reports at least 1 changed record (got ${match4[1]})`
      );
    }
  }

  // ---- B. Brevo request was made ----
  const { options: skewOpts, parsed: skewParsed } = fakeHttps6.captured;
  assert(skewOpts !== null, "clock-skew: Brevo https.request was called");

  if (skewParsed) {
    const attachments4 = skewParsed.attachment || [];
    assert(
      attachments4.length === 1,
      `clock-skew: 1 attachment present (got ${attachments4.length})`
    );

    if (attachments4.length) {
      let csv4 = "";
      try { csv4 = Buffer.from(attachments4[0].content, "base64").toString("utf8"); } catch (_) {}
      assert(csv4.length > 0, "clock-skew: attachment decodes to non-empty string");

      const lines4 = csv4.split(/\r?\n/).filter(Boolean);
      const dataRowCount4 = lines4.length - 1; // subtract header
      assert(
        dataRowCount4 >= 1,
        `clock-skew: CSV contains at least 1 data row (got ${dataRowCount4})`
      );

      const csvBody4 = lines4.slice(1).join("\n");

      // ---- C. The sentinel inserted after the real elapsed gap IS in the CSV ----
      assert(
        csvBody4.includes(SENTINEL_SKEW),
        `clock-skew: sentinel inserted after ~5 ms real elapsed time IS included in the incremental CSV`
      );
    }
  }

  // --- Cleanup ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_SKEW]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm4]);

  const cleanV4 = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_SKEW]
  );
  assert(cleanV4.rows[0].n === 0, "clock-skew: sentinel visit cleaned up");

  const cleanL4 = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm4]
  );
  assert(cleanL4.rows[0].n === 0, "clock-skew: test backup_log rows cleaned up");

  console.log("\n=== Done (clock-skew boundary test) ===");
}

// ---------------------------------------------------------------------------
// Mid-flight update test
//
// Verifies that backup.js correctly handles the race window where a visit is
// updated AFTER the incremental DB query snapshot but BEFORE the backup_log
// write completes.
//
//   Timeline (with fix)
//   -------------------
//   ranAt  captured by backup.js with  new Date()  BEFORE the query runs
//   T1     incremental DB query runs   ──► snapshot frozen in memory
//   T_mid  sentinel visit updated mid-flight (hook fires inside req.end)
//   T_log  backup_log INSERT executes; ran_at = ranAt  (NOT the DB default)
//
//   Because ranAt < T_mid, the next incremental cutoff (= ranAt) is also
//   below T_mid, so the sentinel satisfies  updated_at > ranAt  and WILL
//   appear in the next backup's CSV.
//
// The test also confirms that the CURRENT CSV holds only the pre-update
// values (the snapshot was taken before T_mid), which is correct — the
// current backup accurately reflects what was in the DB at query time.
// ---------------------------------------------------------------------------
async function runMidFlightUpdateTest() {
  console.log("\n=== incremental backup mid-flight update test ===\n");
  console.log(
    "  (Confirms fix: ranAt captured before the query ensures mid-flight\n" +
    "   updates fall inside the NEXT incremental window, not silently lost.)"
  );

  const SENTINEL_CO = "test-backup-mid-flight";
  const NOTES_PRE   = "mid-flight-pre-update";   // value when queried
  const NOTES_POST  = "mid-flight-post-update";  // value after mid-flight update

  // High-water mark for surgical cleanup
  const hwmRes = await pool.query(
    "SELECT COALESCE(MAX(id), 0) AS hwm FROM backup_log"
  );
  const hwm = hwmRes.rows[0].hwm;

  // 1. Seed a successful backup_log row 1 hour ago so we are in incremental mode.
  await pool.query(
    `INSERT INTO backup_log (ran_at, status, note)
     VALUES (NOW() - INTERVAL '1 hour', 'ok',
             'Seeded by mid-flight test — safe to delete')`
  );

  // 2. Insert the sentinel visit NOW() (after the seeded log row → in window).
  await pool.query(
    `INSERT INTO visits (company, attested, notes) VALUES ($1, false, $2)`,
    [SENTINEL_CO, NOTES_PRE]
  );

  // 3. Build a fake-https that runs a hook AFTER req.end() is called but
  //    BEFORE the simulated Brevo response resolves — i.e., between the
  //    DB query snapshot and the backup_log INSERT.
  let capturedMidBody   = "";
  let capturedMidOpts   = null;

  const fakeHttpsMid = {
    request(options, callback) {
      capturedMidOpts = options;
      const { EventEmitter: EE } = require("events");
      const fakeRes = new EE();
      fakeRes.statusCode = 201;

      const fakeReq = new EE();
      fakeReq.setTimeout = () => {};
      fakeReq.destroy   = (err) => fakeReq.emit("error", err);
      fakeReq.write     = (chunk) => { capturedMidBody += chunk; };
      fakeReq.end       = () => {
        // Run the mid-flight update asynchronously, then resolve the response.
        (async () => {
          // Update the sentinel's notes AND updated_at to NOW() while the
          // "email is in flight" — this simulates a real concurrent edit
          // that would move updated_at to T_mid (after ranAt was captured).
          // Without the explicit updated_at update the column stays at the
          // original INSERT time, which is before ranAt, and the assertion
          // about the next window would be wrong.
          await pool.query(
            `UPDATE visits SET notes = $1, updated_at = NOW() WHERE company = $2`,
            [NOTES_POST, SENTINEL_CO]
          );
          // Now deliver the fake 201 response so backup.js can proceed.
          setImmediate(() => {
            callback(fakeRes);
            setImmediate(() => fakeRes.emit("end"));
          });
        })().catch((hookErr) => fakeReq.emit("error", hookErr));
      };
      return fakeReq;
    },
    get captured() {
      return {
        options: capturedMidOpts,
        body:    capturedMidBody,
        parsed:  capturedMidBody ? JSON.parse(capturedMidBody) : null,
      };
    },
  };

  // 4. Run the incremental backup.
  await runWeeklyBackup({ forceFullBackup: false, _httpsOverride: fakeHttpsMid });

  // ---- A. backup_log row ----
  const logRes = await pool.query(
    `SELECT status, note, ran_at FROM backup_log WHERE id > $1 ORDER BY id DESC LIMIT 1`,
    [hwm]
  );
  assert(logRes.rows.length >= 1, "mid-flight: backup_log received at least 1 new row");
  let logRanAt = null;
  if (logRes.rows.length) {
    const { status, note, ran_at } = logRes.rows[0];
    logRanAt = ran_at;
    assert(status === "ok", `mid-flight: backup_log row status = 'ok' (got '${status}')`);
    assert(
      note && note.startsWith("Incremental backup"),
      `mid-flight: backup_log note starts with "Incremental backup" (got: "${note}")`
    );
  }

  // ---- B. Brevo request was made ----
  const { options: midOpts, parsed: midParsed } = fakeHttpsMid.captured;
  assert(midOpts !== null, "mid-flight: Brevo https.request was called");

  if (midParsed) {
    const attachments = midParsed.attachment || [];
    assert(
      attachments.length === 1,
      `mid-flight: 1 attachment present (got ${attachments.length})`
    );

    if (attachments.length) {
      let csv = "";
      try { csv = Buffer.from(attachments[0].content, "base64").toString("utf8"); } catch (_) {}
      assert(csv.length > 0, "mid-flight: attachment decodes to non-empty string");

      const lines  = csv.split(/\r?\n/).filter(Boolean);
      const csvBody = lines.slice(1).join("\n");

      // ---- C. Sentinel IS in the CSV (was queried before the mid-flight update) ----
      assert(
        csvBody.includes(SENTINEL_CO),
        `mid-flight: sentinel company ('${SENTINEL_CO}') IS in the CSV ` +
        `(it was in the incremental window when the query ran)`
      );

      // ---- D. CSV contains PRE-update notes (query snapshot is frozen) ----
      assert(
        csvBody.includes(NOTES_PRE),
        `mid-flight: CSV contains the PRE-update notes ('${NOTES_PRE}') ` +
        `— the DB snapshot was taken before the mid-flight hook ran`
      );

      // ---- E. CSV does NOT contain POST-update notes (snapshot is frozen) ----
      assert(
        !csvBody.includes(NOTES_POST),
        `mid-flight: CSV does NOT contain the POST-update notes ('${NOTES_POST}') ` +
        `— the mid-flight change occurred after the query snapshot (correct)`
      );
    }
  }

  // ---- F. Confirm the NEXT incremental backup CATCHES the mid-flight update.
  //
  //    backup.js now captures ranAt = new Date() BEFORE the visits query runs.
  //    That timestamp is written as backup_log.ran_at (not the DB default NOW()).
  //
  //    Timeline (after the fix):
  //      ranAt  = T_pre_query  (captured before query, written to backup_log)
  //      T_mid  = sentinel update during hook  (T_mid > T_pre_query)
  //      T_log  = when INSERT executes          (T_log ≥ T_mid > T_pre_query)
  //
  //    Next incremental cutoff = backup_log.ran_at = ranAt = T_pre_query.
  //    Sentinel updated_at = T_mid > T_pre_query → included in the next window.
  //
  //    We verify directly: sentinel satisfies  updated_at > backup_log.ran_at.
  if (logRanAt) {
    const nextWindowRes = await pool.query(
      `SELECT COUNT(*)::int AS n FROM visits
        WHERE company = $1 AND updated_at > $2`,
      [SENTINEL_CO, logRanAt]
    );
    assert(
      nextWindowRes.rows[0].n === 1,
      `mid-flight: sentinel updated_at > backup_log.ran_at — ` +
      `the NEXT incremental backup WILL catch the mid-flight update ` +
      `(fix: backup.js captures ranAt before the query and writes it as ran_at)`
    );
  }

  // ---- Confirm the mid-flight update IS in the DB (data integrity is fine) ----
  const currentNotesRes = await pool.query(
    `SELECT notes FROM visits WHERE company = $1`, [SENTINEL_CO]
  );
  assert(
    currentNotesRes.rows.length >= 1 &&
      currentNotesRes.rows[0].notes === NOTES_POST,
    `mid-flight: sentinel DB row now has POST-update notes ('${NOTES_POST}') ` +
    `— the update committed successfully, just not captured in the backup CSV`
  );

  // --- Cleanup ---
  await pool.query("DELETE FROM visits WHERE company = $1", [SENTINEL_CO]);
  await pool.query("DELETE FROM backup_log WHERE id > $1", [hwm]);

  const cleanV = await pool.query(
    "SELECT COUNT(*)::int AS n FROM visits WHERE company = $1", [SENTINEL_CO]
  );
  assert(cleanV.rows[0].n === 0, "mid-flight: sentinel visit cleaned up");

  const cleanL = await pool.query(
    "SELECT COUNT(*)::int AS n FROM backup_log WHERE id > $1", [hwm]
  );
  assert(cleanL.rows[0].n === 0, "mid-flight: test backup_log rows cleaned up");

  console.log("\n=== Done (mid-flight update test) ===");
}

run()
  .then(() => runIncrementalTest())
  .then(() => runIncrementalNoChangeTest())
  .then(() => runBoundaryTest())
  .then(() => runBoundaryPlusOneTest())
  .then(() => runClockSkewTest())
  .then(() => runMidFlightUpdateTest())
  .catch((err) => {
    console.error("Unexpected error:", err);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
